The attached tests are using CMake and Google Test.

Disclaimer: The tests are:
1. AI generated (Not always correct) - This means that the course staff does not guarantee the correctness of these tests.
2. Not complete - If you want a good grade, it is your responsibility to write your own tests.
3. May not be up to date with the latest changes - and we will not update them for you.

Additionaly, we will not answer questions directly about how to *set up* the tests, you can use ChatGPT for that.
Why? For example, the question "How do I setup CMake?" depends on your OS, where you installed your IDE, how your environment is configured, etc.