//
// Created by talta on 10/05/2025.
//

#ifndef ASGN2_BATTLEINFO_H
#define ASGN2_BATTLEINFO_H

class BattleInfo {
public:
    virtual ~BattleInfo() {}
};


#endif //ASGN2_BATTLEINFO_H
